const express = require('express');
const AWS = require('aws-sdk');
const bodyParser = require('body-parser');
const app = express();
const port = process.env.PORT || 8080;

// Configure AWS SDK
AWS.config.update({ region: 'us-east-2' }); // Your DynamoDB region
const docClient = new AWS.DynamoDB.DocumentClient();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static(__dirname));

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

app.post('/signup', (req, res) => {
  const { name, email, studentid } = req.body;

  const params = {
    TableName: 'beanstalkapp-table',
    Item: {
      email: email,
      name: name,
      studentid: studentid,
      timestamp: new Date().toISOString()
    }
  };

  docClient.put(params, (err, data) => {
    if (err) {
      console.error('DynamoDB Error:', err);
      res.status(500).send('❌ Error saving data to DynamoDB.');
    } else {
      res.send('✅ Signup saved successfully!');
    }
  });
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
